blink with:
arrow keys!
script by:
KotzEimer